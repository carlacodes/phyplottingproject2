API Reference
=============

.. automodule:: neo.core

.. testsetup:: *

    from neo import SpikeTrain
    import quantities as pq
