****************
Examples
****************

.. currentmodule:: neo

Introduction
=============

A set of examples in :file:`neo/examples/` illustrates the use of Neo classes.



.. literalinclude:: ../../examples/read_files_neo_io.py

.. literalinclude:: ../../examples/read_files_neo_rawio.py

.. literalinclude:: ../../examples/simple_plot_with_matplotlib.py

