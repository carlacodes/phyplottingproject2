See http://neo.readthedocs.io/en/latest/developers_guide.html
