from .neobaseextractor import NeoBaseRecordingExtractor, NeoBaseSortingExtractor


class CustomTdtRecordingExtractor(NeoBaseRecordingExtractor):
    """
    Class for reading TDT folder

    Based on neo.rawio.TdTRawIO

    Parameters
    ----------
    folder_path: str
        The tdt folder.
    stream_id: str or None
    """
    mode = 'folder'
    NeoRawIOClass = 'CustomTdtRawIO'

    def __init__(self, folder_path, stream_id=None, store=['BB_2','BB_3','BB_4','BB_5']):
        neo_kwargs = {'dirname': folder_path, 'store': store}
        NeoBaseRecordingExtractor.__init__(self, stream_id=stream_id, **neo_kwargs)

        self._kwargs = dict(folder_path=str(folder_path), stream_id=stream_id, store=store)


def read_customtdt(*args, **kwargs):
    recording = CustomTdtRecordingExtractor(*args, **kwargs)
    return recording


read_customtdt.__doc__ = CustomTdtRecordingExtractor.__doc__
