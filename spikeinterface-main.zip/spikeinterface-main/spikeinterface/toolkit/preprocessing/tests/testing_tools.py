import numpy as np

from spikeinterface import NumpyRecording

from probeinterface import generate_linear_probe

if __name__ == '__main__':
    pass
