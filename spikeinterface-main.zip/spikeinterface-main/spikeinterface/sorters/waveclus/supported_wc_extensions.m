function formats = supported_wc_extensions()
    % Return a cell of arrays with the formats supported/needed for spikeinterface.
    formats = {'h5', 'mat'};
end
