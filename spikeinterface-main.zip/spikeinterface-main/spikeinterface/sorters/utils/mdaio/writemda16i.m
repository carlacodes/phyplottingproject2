function writemda16i(X,fname)
writemda(X,fname,'int16');
end