Sorters tutorials
-----------------

The :code:`sorters` module wraps several spike sorting algorithms with the same simple Python API.

- run sorters with different parameters
- spike sort by property
- use the sorter launcher
