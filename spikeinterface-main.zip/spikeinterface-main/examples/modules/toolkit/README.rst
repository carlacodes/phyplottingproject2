Toolkit tutorials
-----------------

The :code:`spikeinterface.toolkit` module allows users to preprocess and postprocess the data, to compute
validation metrics, and to perform automatic curation of spike sorting outputs.

- preprocessing
- postprocessing
- qualitymetrics
- curation
