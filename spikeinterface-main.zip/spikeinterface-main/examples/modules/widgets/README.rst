Widgets tutorials
-----------------

The :code:`widgets` module contains several plotting routines (widgets) for
visualizing recordings and sorting data, probe layout, and many more!

