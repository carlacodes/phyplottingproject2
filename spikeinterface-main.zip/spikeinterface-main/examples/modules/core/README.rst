Core tutorials
--------------------

The :code:`core` module

- RecordingExtractor
- SortingExtractor
- Handling probe information
