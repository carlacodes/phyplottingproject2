'''
Handling probe information
===========================

In order to properly spike sort, you may need to load information related to the probe you are using.

:code:`spikeinterface` internally uses `probeinterface <https://probeinterface.readthedocs.io/>`_ to handle
probe or probe groups for recordings.

Depending the dataset the `Probe` object can be already included or you needs to be set manually.

Here's how!
'''
import numpy as np
import spikeinterface.extractors as se

##############################################################################
# First, let's create a toy example:

recording, sorting_true = se.toy_example(duration=10, num_channels=32, seed=0, num_segments=2)
print(recording)

###############################################################################
# This generator already contain a probe object that you can retrieve
# directly an plot:

probe = recording.get_probe()
print(probe)

from probeinterface.plotting import plot_probe

plot_probe(probe)

###############################################################################
# You can also overwrite the probe. In that case you need to manually make
# the wiring (e.g. virtually connect each electrode to the recording device).
# Let's use a probe from Cambridge Neurotech with 32 channels:

from probeinterface import get_probe

other_probe = get_probe('cambridgeneurotech', 'ASSY-37-E-1')
print(other_probe)

other_probe.set_device_channel_indices(np.arange(32))
recording_2_shanks = recording.set_probe(other_probe, group_mode='by_shank')
plot_probe(recording_2_shanks.get_probe())

###############################################################################
# Now let's check what we have loaded. The `group_mode='by_shank'` automatically
# set the 'group' property depending on the shank id.
# We can use this information to split the recording in two sub recordings:

print(recording_2_shanks)
print(recording_2_shanks.get_property('group'))

rec0, rec1 = recording_2_shanks.split_by(property='group')
print(rec0)
print(rec1)

###############################################################################
# Note that some formats (MEArec, SpikeGLX) automatically handle the probe
# geometry. For almost all other formats the probe and the wiring have
# to be set manually using the :code:`probeinterface` library.
