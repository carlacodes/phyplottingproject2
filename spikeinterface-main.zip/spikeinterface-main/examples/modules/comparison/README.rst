Comparison tutorials
--------------------

The :code:`comparison` module allows to compare spike sorting output
with and without ground-truth information.

