Extractors tutorials
--------------------

The :code:`extractors` module is designed to load and save recorded and sorted data and to handle probe information.

- RecordingExtractor
- SortingExtractor
- Handling probe information
