Widgets module
==============

The :code:`widgets` module includes matplotlib-based plotting function to visualize recordings, sortings, waveforms,
and more.

Checkout the :ref:`_sphx_glr_modules_widgets` tutorials for an overview of available widgets!
