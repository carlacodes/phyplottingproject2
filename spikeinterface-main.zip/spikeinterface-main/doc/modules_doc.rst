Modules documentation
=====================

.. toctree::
    :maxdepth: 1

    module_core
    module_extractors
    module_toolkit
    module_sorters
    module_comparison
    module_exporters
    module_widgets
    module_sorting_components

