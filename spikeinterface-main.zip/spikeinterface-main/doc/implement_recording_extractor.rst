Build a RecordingExtractor
----------------------------


TODO
