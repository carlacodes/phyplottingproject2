Build a SortingExtractor
------------------------


# TODO
